﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ContosoUniversity.Models
{
    public class BloodSugar
    {
        public int ID { get; set; }

        public string ClientID { get; set; }

        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd hh:mm:tt}", ApplyFormatInEditMode = true)]
        public DateTime DateTime { get; set; }

        [Required]
        public float Value { get; set; }

    }
}
